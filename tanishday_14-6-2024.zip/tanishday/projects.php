  
  
  
<?php include 'header.php';?>


  
  
  <main id="main">

    <!-- ======= Why Us Section ======= -->
	
	<br><br>
<section>
      <div class="container aos-init aos-animate" data-aos="fade-up" style="text-align:center;    font-family: Oswald;font-width:300;">
<h2>EFFECT OF ENVIRONMENT ON HERITAGE INFRASTRUCTURE</h2>
 <div style=" color:#000;   position: relative;
    
        border: none;
        height: 8px;
        background: red;
        margin-bottom: 5px;color:#000;">
		
		<hr>
		</div>
      </div>

   
   	 

    </section>
	

	


    <section id="about" class="about section-bg" style="background-color: #fff;">
      <div class="container">

        <div class="row">
          <div class="col-12 col-lg-12 data-aos="fade-right">
   
		




<table class="table table-striped"> 
                                            <tbody>
                                                                                                                                                <tr>
                                                    <td>1</td>
                                                    <td style="text-align: justify;">Study for the optimum height of lift for mass concreting in concrete dam structures</td>
                                                    <td>Ongoing</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(17)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>2</td>
                                                    <td style="text-align: justify;">Digital twin development employing Bayesian filters with sub structured predictor models for aerospace structures applications</td>
                                                    <td>Ongoing</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(18)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>3</td>
                                                    <td style="text-align: justify;">Water and energy efficient reliable irrigation system (watEr-ERIS): Solar energy and cloud-based decision support systems for automated irrigation system</td>
                                                    <td>Completed</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(35)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>4</td>
                                                    <td style="text-align: justify;">Vibration based health monitoring of tensegrity structures incorporating and effects of ambient temprature</td>
                                                    <td>Completed</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(36)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>5</td>
                                                    <td style="text-align: justify;">Development of damage technique for composite laminated structures under varying temprature</td>
                                                    <td>Completed</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(37)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>6</td>
                                                    <td style="text-align: justify;">Condition assessment of bridges under HPPWD division Seraj, Janjehli, Manali (Himachal Pradesh)</td>
                                                    <td>Ongoing</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(43)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>7</td>
                                                    <td style="text-align: justify;">Site inspection visit for structural audit of Jawahar Navodaya Vidalays School buildings in Himachal Pradesh</td>
                                                    <td>Ongoing</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(45)">View More</button>
                                                    </td>
                                                </tr>
                                                                                                <tr>
                                                    <td>8</td>
                                                    <td style="text-align: justify;">Regarding providing expertise in the execution of bridge construction under PMGSY</td>
                                                    <td>Ongoing</td>
                                                    <td>
                                                    <button type="button" class="btn btn-primary myLargeModalLabel" data-toggle="modal" data-target=".bd-example-modal-lg" onclick="project_fdetails(46)">View More</button>
                                                    </td>
                                                </tr>
                                                                                            </tbody>
                                        </table>
          </div>

       
		 
		  
		   <div style=" color:#000;   position: relative;
    
        border: none;
        height: 3px;
        background: red;
        color:#000;margin-top:0.5em;">
		
	
		
		
	
		</div>
        </div>

      </div>
    </section>
	
	

	
	
	
	
 <section>
      <div class="container aos-init aos-animate" data-aos="fade-up" style="font-family: Oswald;  ;
    text-align:center;">
<p>*Lorem Ipsum is simply dummy text of the printing and typesetting industry.Lorem Ipsum has been the industry's standard dummy text ever since</p>
	   <div style=" color:#000;   position: relative;
    
        border: none;
        height: 3px;
        background: red;
        color:#000;">
		
	
		
		
	
		
		
		<p style="text-align-center;"><b> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</b></p>
		</div>
      </div>

   
   	 

    </section>
  </main><!-- End #main -->

<?php include 'footer.php';?>

